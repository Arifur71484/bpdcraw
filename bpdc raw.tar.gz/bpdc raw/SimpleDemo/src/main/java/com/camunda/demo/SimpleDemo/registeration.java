package com.camunda.demo.SimpleDemo;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class registeration implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
        System.out.print("Get user information from registeration form ");	            
        System.out.println(""); 

	}

}
