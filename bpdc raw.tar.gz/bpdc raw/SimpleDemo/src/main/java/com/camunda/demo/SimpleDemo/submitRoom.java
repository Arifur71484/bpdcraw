package com.camunda.demo.SimpleDemo;

import java.util.Random;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class submitRoom implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		//Do you want to submit the room?
		//If no, terminate the process
		//If yes, go for payment
		Random rando = new Random();
		execution.setVariable("submit", rando.nextBoolean());
	}

}
