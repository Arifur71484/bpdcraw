package com.camunda.demo.SimpleDemo;

import java.util.Random;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class visitWebsite implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		//we dont need do any action here, just visit website, if you are a new user you must register and create an account.
		//Otherwise you can log in with user and pass 
		Random rando = new Random();
		execution.setVariable("newuser", rando.nextBoolean());

	}

}
