package com.camunda.demo.SimpleDemo;

import java.util.Random;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class BookRoom implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		//if this room is not available, notify costumer and terminate the request
		//if this room is available, show the price and details for submission
		Random rando = new Random();
		execution.setVariable("availability", rando.nextBoolean());
	}

}
