package com.camunda.demo.SimpleDemo;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class RecordinDB implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		// add new user to database. Insert into user table 
        System.out.print("Connecting to a selected database... ");	            
        System.out.println("Successfully connected!"); 
        System.out.println("Insert data in user table"); 


	}

}
