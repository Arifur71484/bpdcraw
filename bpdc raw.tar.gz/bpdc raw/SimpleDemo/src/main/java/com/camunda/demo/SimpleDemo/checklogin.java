package com.camunda.demo.SimpleDemo;

import java.util.Random;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class checklogin implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		//check it in user table! weather this user exist in database or not?
		Random pass = new Random();
		
		execution.setVariable("password", pass.nextBoolean());

	}

}
