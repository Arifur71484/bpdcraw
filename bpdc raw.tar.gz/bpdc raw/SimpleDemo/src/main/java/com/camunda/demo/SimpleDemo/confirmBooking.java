package com.camunda.demo.SimpleDemo;

import java.util.Random;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class confirmBooking implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		//search in hotel list/database weather this room is available or no
		Random rando = new Random();
		execution.setVariable("confirm", rando.nextBoolean());

	}

}
