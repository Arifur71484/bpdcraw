package com.camunda.demo.SimpleDemo;

import java.util.Random;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class checkPayment implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		// check card number, amount, card code, ... if everything is correct then pay successfully, else discard payment and notify costumer
		Random rando = new Random();
		
		execution.setVariable("successfullPayment", rando.nextBoolean());

	}

}
